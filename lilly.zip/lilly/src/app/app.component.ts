import { Component, OnInit, ViewChild } from '@angular/core';
//import { CalendarComponent } from 'ng-fullcalendar';
//import { Options } from 'fullcalendar';
import { EventSesrvice } from './event.service';
import * as $ from 'jquery';
//import 'fullcalendar';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit  {
  calendarOptions = {
    editable: true,
    eventLimit: false,
    contentHeight: 600,
    defaultView: 'month',
    // customize the button names,
  // otherwise they'd all just say "list"
  views: {
    listMonth: { buttonText: 'list month' },
    agendaWeek: { buttonText: 'agendaWeek' },
    agendaDay: { buttonText: 'agendaDay' },
    month: { buttonText: 'month' }
  },
    header: {
      left: 'prev,next today',
      center: 'title',
      right: 'listMonth,agendaWeek,agendaDay,month'
    },
    events: this.eventService.modData,
    eventClick: function(calEvent, jsEvent, view) {

      //$('#calendar').fullCalendar('removeEvents',calEvent._id);
      // change the border color just for fun
      //$(this).css('border-color', 'red');

    },
    /*eventRender: function(event, element) {
      element.find(".fc-bg").css("pointer-events","none");
      element.append("<div style='position:absolute;bottom:-1px;right:-1px;' ><button style='width:19px;height:19px;' type='button' id='btnDeleteEvent_" + event._id + "' class='btn btn-block btn-primary btn-flat m-0 p-0'>X</button></div>" );
      $("#btnDeleteEvent_" + event._id).click(function() {
        $('#calendar').fullCalendar('removeEvents',event._id);
     });},*/
     dayRender: function(date, cell) {
      console.log('dddd');
  },
  eventDblClick: function (calEvent, jsEvent, view) {
    // Create a new appointment
    console.log('eventDblClick');
 },
  eventRender: function(event, element) {
      element.append( "<span id='closeon' style='bottom:5px;right:5px;color:white'>[remove]</span>" );
      element.find("#closeon").click(function() {
        var r = confirm("really delete?");
        if (r == true) {
          $('#calendar').fullCalendar('removeEvents',event._id);
        }
      });
  },
  dayClick: function(date, jsEvent, view) {
    alert('Clicked on: ' + date.format());
    alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);
    alert('Current view: ' + view.name);
    var r = confirm("really add event?");
    if (r == true) {
      $('#calendar').fullCalendar('addEventSource', [{
        id: 999,
        title: 'MSL訪問ー西田 龍平',
        start: date.format(),
        color: 'yellow'
      }]);
    }
    // change the day's background color just for fun
    //$(this).css('background-color', 'red');
  }
};

  shortOptions = {
    editable: true,
    eventLimit: false,
    contentHeight: 600,
    defaultView: 'listMonth',
    eventClick: function(calEvent, jsEvent, view) {

      alert('Event: ' + calEvent.title);
      alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);
      alert('View: ' + view.name);

      // change the border color just for fun
      $(this).css('border-color', 'red');

    },
    dayClick: function(date, jsEvent, view) {
      alert('Clicked on: ' + date.format());
      alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);
      alert('Current view: ' + view.name);
      // change the day's background color just for fun
      $(this).css('background-color', 'red');
    },
    header: {
      left: '',
      center: 'title',
      right: ''
    },
    events: this.eventService.modData
};
 displayEvent: any;
 displayTab = false;
 data = null;
 containerEl = null;
 calendar = null;
  constructor(protected eventService: EventSesrvice) { }
  ngAfterViewInit() {
       let containerEl: JQuery = $('#calendar');
       this.containerEl = containerEl;
       if (this.displayTab) {
        this.calendar = containerEl.fullCalendar(this.shortOptions);
       } else {
        this.calendar = containerEl.fullCalendar(this.calendarOptions);
       }
  }
  ngOnInit() {
    //let containerEl: JQuery = $('#calendar');
    this.eventService.getEvents().subscribe(data => {
      this.data = data;
    });
  }
  clickButton(model: any) {
    this.displayEvent = model;
  }
  eventClick(model: any) {
    model = {
      event: {
        id: model.event.id,
        start: model.event.start,
        end: model.event.end,
        title: model.event.title,
        allDay: model.event.allDay
        // other params
      },
      duration: {}
    }
    this.displayEvent = model;
  }
  updateEvent(model: any) {
    model = {
      event: {
        id: model.event.id,
        start: model.event.start,
        end: model.event.end,
        title: model.event.title
        // other params
      },
      duration: {
        _data: model.duration._data
      }
    }
    this.displayEvent = model;
  }
  scale() {
    this.displayTab = !this.displayTab;
    if (!this.displayTab) {
      this.containerEl.fullCalendar('destroy');
      this.containerEl.fullCalendar(this.calendarOptions);
      this.containerEl.fullCalendar('render');
    } else {
      this.containerEl.fullCalendar('destroy');
      this.containerEl.fullCalendar(this.shortOptions);
    }
  }
}
