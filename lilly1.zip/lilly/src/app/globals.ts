export class SharedService {
  slotDate = null;

dayClickCallback(date) {
  this.slotDate = date;
  $('#calendar').on('mousemove', this.forgetSlot);
}
eventRenderCallback(event, element){
element.on('dblclick', function() {
      this.dblClickFunction(event.start);
  });
}
 forgetSlot() {
  this.slotDate = null;
  $('#calendar').off('mousemove', this.forgetSlot);
}
 dblClickFunction(date) {
  alert(date);
}
}
